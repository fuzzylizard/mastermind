package com.example.mastermind

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MastermindApplicationTests {

	@Test
	fun contextLoads() {
	}

}
